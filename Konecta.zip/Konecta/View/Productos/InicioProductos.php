
<a href="?Controller=Producto&View=CrearProducto" class="btn btn-info mt-4"> Agregar Un Nuevo Producto </a>
<div class="card text-center mt-5">
  <div class="card-header">
Lista de productos
  </div>
  <div class="card-body p-3">
  <h5 class="card-title">Lista De productos</h5>
  <table class="table">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">NOMBRE_PRODUCTO</th>
      <th scope="col">REFERENCIA</th>
      <th scope="col">PRECIO</th>
      <th scope="col">PESO</th>
      <th scope="col">CATEGORIA</th>
      <th scope="col">STOCK</th>
      <th scope="col">FECHA_CREACION</th>
      <th scope="col">ACCIONES</th>

    </tr>
  </thead>
  <tbody>
      
      <?php
     
      foreach($productos as $producto){?>
    <tr>
      <th scope="row"><?php echo $producto['ID'];?></th>
      <td><?php echo $producto['NOMBRE_PRODUCTO'];?></td>
      <td><?php echo $producto['REFERENCIA'];?></td>
      <td><?php echo $producto['PRECIO'];?></td>
      <td><?php echo $producto['PESO'];?>g</td>
      <td><?php echo $producto['CATEGORIA'];?></td>
      <td><?php echo $producto['STOCK'];?></td>
      <td><?php echo $producto['FECHA_CREACION'];?></td>
      <td><a href="?Controller=Producto&View=EditarVistaProducto&ID=<?php echo $producto['ID'];?>" class="btn btn-warning"> Editar </a>
      <a  onClick="return confirm('Desea eliminar el elemento?')" href="?Controller=Producto&View=EliminarProducto&ID=<?php echo $producto['ID'];?>" class="btn btn-danger"> Eliminar </a> 
    </td>
      
    </tr>
   <?php } ?>
  </tbody>
</table>
  </div>
  <div class="card-footer text-muted">
   
  </div>
</div>


