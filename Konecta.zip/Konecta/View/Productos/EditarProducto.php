
<div class="card text-center mt-5">
  <div class="card-header">
   
  </div>
  <div class="card-body m-3">
    <h5 class="card-title">Editar producto</h5>
    

<form method="POST" action="?Controller=Producto&View=EditarInformacionProducto">

<div class="row">
    <input type="hidden" name="id" id="id" value="<?php echo $producto->ID;?>">
    <div class="col-md-6">
  <div class="form-group">

    <label for="nombre">Nombre</label>
    <input type="text" class="form-control" value="<?php echo $producto->NOMBRE_PRODUCTO; ?>" id="nombre" name="nombre" aria-describedby="emailHelp">
   
  </div>
</div>
<div class="col-md-6">
  <div class="form-group">
    <label for="exampleInputPassword1">Referencia</label>
    <input type="text" class="form-control" value="<?php echo $producto->REFERENCIA; ?>" id="referencia" name="referencia">
  </div>
</div>
<div class="col-md-6">
  <label class="form-check-label" for="exampleCheck1">Precio</label>
    <input type="number" class="form-control" value="<?php echo $producto->PRECIO; ?>" id="precio" name="precio"> 
</div>
<div class="col-md-6">
  <label class="form-check-label" for="exampleCheck1">Peso</label>
    <input type="number" class="form-control" value="<?php echo $producto->PESO; ?>" id="peso" name="peso"> 
</div>
  
<div class="col-md-6">
  <label class="form-check-label" for="exampleCheck1">Categoria</label>
    <input type="text" class="form-control" value="<?php echo $producto->CATEGORIA; ?>" id="categoria" name="categoria"> 
</div>

<div class="col-md-6">
  <label class="form-check-label" for="exampleCheck1">Stock</label>
    <input type="number" class="form-control" value="<?php echo $producto->STOCK; ?>" id="stock" name="stock"> 

</div>
<div class="m-auto p-5">
<input type="submit" value="Enviar Formulario" class="btn btn-primary">
</div>
 
</form>

</div>
  <div class="card-footer text-muted">
 
  </div>
</div>
