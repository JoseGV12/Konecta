

<div class="row justify-content-center mt-5">

<?php
foreach($productos as $pro){
?>
  <div class="col-sm-6">
    <div class="card ">
      <div class="card-body text-center">
        <h5 class="card-title text-center">NOMBRE: <?php echo $pro['NOMBRE_PRODUCTO'];?></h5>
        <p class="card-text text-center">REFERENCIA: <?php echo $pro['REFERENCIA'];?></p>
        <p class="card-text text-center">STOCK: <?php echo  $pro['STOCK'];?></p>
        <a href="?Controller=Producto&View=EditarVistaProducto&ID=<?php echo $pro['ID'];?>" class="btn btn-primary">Editar</a>
      </div>
    </div>
    <?php }?>
</div>