
<div class="card text-center mt-5">
  <div class="card-header">
   
  </div>
  <div class="card-body m-3">
    <h5 class="card-title">Editar</h5>
    
    <form method="POST" action="#"> 
      <div class="row">

        <div class="col-md-6">
        <div class="form-group">
          <label for="nombre">Editar Producto</label>
            <input required type="text" class="form-control" id="nombre" name="nombre" aria-describedby="emailHelp">
          </div>
        </div>

        <div class="col-md-6">
          <div class="form-group">
            <label for="exampleInputPassword1">Referencia</label>
            <input required  type="text" class="form-control" id="referencia" name="referencia">
          </div>
</div>
          <div class="col-md-6">
            <label class="form-check-label" for="exampleCheck1">Precio</label>
              <input required  type="number" class="form-control" id="precio" name="precio"> 
            </div>
          <div class="col-md-6"> 
            <label class="form-check-label" for="exampleCheck1">Peso</label>
            <input type="number" class="form-control" id="peso" name="peso">
          </div>
          <div class="col-md-6">

          <label class="form-check-label" for="exampleCheck1">Peso</label>
    <input type="number" required  class="form-control" id="peso" name="peso"> 

          </div>
          <div class="col-md-6">

          <label class="form-check-label" for="exampleCheck1">Categoria</label>
    <input type="text" required  class="form-control" id="categoria" name="categoria"> 

          </div>
          <div class="col-md-12">
              <label class="form-check-label" for="exampleCheck1">Stock</label>
    <input type="number" class="form-control" id="stock" name="stock"> 
          </div>
      </div>

      </div>
  
  
  
 

  
 
  

 
 

  



  <input type="submit" value="Enviar Formulario" class="btn btn-primary">
</form>


  </div>
  <div class="card-footer text-muted">
 
  </div>
</div>
