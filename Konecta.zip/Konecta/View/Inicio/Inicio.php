<div class="container mt-5">
    <div class="row">
        <a href="?Controller=Producto&View=InicioProducto" style="text-decoration:none;color:black">

        <div class="col">
        <div class="card mb-3" style="max-width: 540px;">
  <div class="row no-gutters">
    <div class="col-md-4">
      <img src="http://www.solofondos.com/wp-content/uploads/2015/11/21omxpw.jpg" height="100%" width="100%" alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title">Productos</h5>
        <p class="card-text">Ver todo el listado de productos</p>
        <p class="card-text"><small class="text-muted"></small></p>
      </div>
    </div>
  </div>
</div>
        </a>
        
            <!--dd-->

        </div>
        <a href="?Controller=Venta&View=InicioVenta" style="text-decoration:none;color:black">
        <div class="col">
        <div class="card mb-3" style="max-width: 540px;">
  <div class="row no-gutters">
    <div class="col-md-4">
      <img src="http://www.solofondos.com/wp-content/uploads/2015/11/21omxpw.jpg" height="100%" width="100%" alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title">Ver las ventas</h5>
        <p class="card-text">Ver todo el listado de Ventas</p>
        <p class="card-text"><small class="text-muted"></small></p>
      </div>
    </div>
  </div>
  </a>
</div>

        </div>
        <a href="?Controller=Venta&View=VentaPorProducto" style="text-decoration:none;color:black">
        <div class="col">
        <div class="card mb-3" style="max-width: 540px;">
  <div class="row no-gutters">
    <div class="col-md-4">
      <img src="http://www.solofondos.com/wp-content/uploads/2015/11/21omxpw.jpg" height="100%" width="100%" alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title">Ver venta por producto</h5>
        <p class="card-text">Ver la venta por producto</p>
        <p class="card-text"><small class="text-muted"></small></p>
      </div>
    </div>
  </div>
</div>
            <!--dd-->
            </a>
        </div>

    </div>
</div>