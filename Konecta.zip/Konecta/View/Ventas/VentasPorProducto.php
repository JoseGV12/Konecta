<a href="?Controller=Venta&View=CrearVenta" class="btn btn-info mt-5"> Agregar Una Venta </a>
<div class="card text-center mt-5">
  <div class="card-header">
    Ventas
  </div>
  <div class="card-body">
    <h5 class="card-title">Ventas</h5>
<table class="table">
  <thead>
    <tr>
      <th scope="col">ID VENTA</th>
      <th scope="col">ID PRODUCTO</th>
      <th scope="col">NOMBRE PRODUCTO</th>
      <th scope="col">NUMERO DE VENTAS</th>
      <th scope="col">STOCK</th>
    </tr>
  </thead>
  <tbody>
      <?php foreach($ventas_por_producto as $venta){ ?> 
    <tr>
      <th scope="row"><?php echo  $venta['ID_VENTA'] ?></th>
      <td><?php echo $venta['ID_PRODUCTO'] ?></td>
      <td><?php echo $venta['NOMBRE_PRODUCTO'] ?></td>
      <td><?php echo  $venta['NUMERO_VENTAS'] ?></td>
      <td><?php echo  $venta['STOCK'] ?></td>
    </tr>
  <?php } ?>
  </tbody>
</table>
</div>
  <div class="card-footer text-muted">
  
  </div>
</div>