<?php

require_once("Model/VentaModel.php");
class VentaController{

   public function InicioVenta(){
$ventas=Venta::inicio();

include_once("View/Ventas/InicioVentas.php");

    }

    public function CrearVenta(){
    if(isset($_POST['cantvender'])  && isset($_POST['idpro'])){
        $id_producto=$_POST['idpro'];
        $cantidad=$_POST['cantvender'];
     $var=Venta::crear($id_producto,$cantidad);
      //  include_once("View/Ventas/CrearVenta.php");
    switch($var){
        case 0:
            echo "<script>Swal.fire('Se ha vendido el producto correctamente!','Click para continuar!','success')
              </script>";
              $_SESSION["VENTA"] = "agregada";
              $ventas=Venta::inicio();
              
              include_once("View/Ventas/InicioVentas.php");

            break;
        case 2:
            echo "
            <script>
            Swal.fire({
                icon: 'error',
                title: 'No se puede vender esta cantidad',
                text: 'El producto no cuenta con ese stock disponible'
              })
              </script>
              ";
             
              $ventas=Venta::inicio();
              
              include_once("View/Ventas/InicioVentas.php");
            break;
            case 1:
                echo "
                <script>
                Swal.fire({
                    icon: 'error',
                    title: 'No se puede encontrar el producto',
                    text: 'El producto no se encontró.'
                  })
                  </script>
                  ";
                  $ventas=Venta::inicio();
              
              include_once("View/Ventas/InicioVentas.php");
                break;
    }
    
     
    }else {
        # code...
        include_once("View/Ventas/CrearVenta.php");

    }


    }
    public function VentaPorProducto(){
        $ventas_por_producto=Venta::VentaPorProducto();
        include_once("View/Ventas/VentasPorProducto.php");
    }
}

?>