<?php
class InicioController{
   public function inicio(){
       include_once("View/Inicio/Inicio.php");
   }
}


?>