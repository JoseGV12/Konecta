<?php
include_once("Model/Conexion.php");
class Producto{

    public $ID;
    public $NOMBRE_PRODUCTO;
    public $REFERENCIA;
    public $PRECIO;
    public $PESO;
    public $CATEGORIA;
    public $STOCK;
    public $FECHA_CREACION;

    public function __construct($ID,$NOMBRE_PRODUCTO,$REFERENCIA,$PRECIO,$PESO,$CATEGORIA,$STOCK,$FECHA_CREACION){
        $this->ID=$ID;
        $this->NOMBRE_PRODUCTO=$NOMBRE_PRODUCTO;
        $this->REFERENCIA=$REFERENCIA;
        $this->PRECIO=$PRECIO;
        $this->PESO=$PESO;
        $this->CATEGORIA=$CATEGORIA;
        $this->STOCK=$STOCK;
        $this->FECHA_CREACION=$FECHA_CREACION;

    }
    public static function inicio(){
        $listaproductos=[];
        $con=DB::CrearInstancia();
        $producto=$con->query("SELECT * FROM PRODUCTOS");
        $productos=$producto->fetchAll();
        return  $productos;
    }

    public static function crear($NOMBRE_PRODUCTO,$REFERENCIA,$PRECIO,$PESO,$CATEGORIA,$STOCK){
        $con=DB::CrearInstancia();
        $sql=$con->prepare("INSERT INTO PRODUCTOS(NOMBRE_PRODUCTO,REFERENCIA,PRECIO,PESO,CATEGORIA,STOCK) VALUES(?,?,?,?,?,?)");
        $sql->execute(array($NOMBRE_PRODUCTO,$REFERENCIA,$PRECIO,$PESO,$CATEGORIA,$STOCK));

    }
    public static function editar($ID){
        $con=DB::CrearInstancia(); 
        $sql=$con->prepare("SELECT * FROM PRODUCTOS WHERE ID=?");
        $sql->execute(array($ID));
        $producto=$sql->fetch();
        $producto_final=new Producto($producto['ID'],$producto['NOMBRE_PRODUCTO'],$producto['REFERENCIA'],$producto['PRECIO'],$producto['PESO'],$producto['CATEGORIA'],$producto['STOCK'],$producto['FECHA_CREACION']);
    return $producto_final;
    }

    public static function eliminar($ID){
        $con=DB::CrearInstancia(); 
        $sql=$con->prepare("DELETE FROM PRODUCTOS WHERE ID=?");
        $sql->execute(array($ID));
        
    }

    public static function guardar($ID,$NOMBRE_PRODUCTO,$REFERENCIA,$PRECIO,$PESO,$CATEGORIA,$STOCK){
        $con=DB::CrearInstancia();
        $sql=$con->prepare("UPDATE PRODUCTOS SET NOMBRE_PRODUCTO=?,REFERENCIA=?,PRECIO=?,PESO=?,CATEGORIA=?,STOCK=? WHERE ID=?");
        $sql->execute(array($NOMBRE_PRODUCTO,$REFERENCIA,$PRECIO,$PESO,$CATEGORIA,$STOCK,$ID));
    }
    public static function ProductoMasStock(){
        $con=DB::CrearInstancia();
        $sql=$con->query("SELECT * FROM PRODUCTOS ORDER BY STOCK DESC LIMIT 1");
        $productos=$sql->fetchAll();
        return $productos;
    }


}


?>