<?php
class DB{
    private static $con=null;
    public static function CrearInstancia(){
        if(!isset(self::$con)){
            $con=new PDO("mysql:host=localhost;dbname=konecta","root","");
        }
        return $con;
    }
}

?>