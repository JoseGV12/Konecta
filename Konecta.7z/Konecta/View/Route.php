<?php
switch($get_controller){
case "Producto":
    if($get_view=="InicioProducto"){
        include_once("Controller/ProductoController.php");
        $objectController=$get_controller."Controller";
        $controller=new $objectController();
        $controller->$get_view();

    }elseif ($get_view=="CrearProducto") {
        include_once("Controller/ProductoController.php");
        $objectController=$get_controller."Controller";
        $controller=new $objectController();
        $controller->$get_view();

    }elseif($get_view=="EditarVistaProducto"){
        include_once("Controller/ProductoController.php");
        $objectController=$get_controller."Controller";
        $controller=new $objectController();
        $controller->$get_view();

    }elseif($get_view=="EditarInformacionProducto"){
        include_once("Controller/ProductoController.php");
        $objectController=$get_controller."Controller";
        $controller=new $objectController();
        $controller->$get_view();

    }elseif($get_view=="EliminarProducto"){
        include_once("Controller/ProductoController.php");
        $objectController=$get_controller."Controller";
        $controller=new $objectController();
        $controller->$get_view();

    }elseif($get_view=="ProductoMasStock"){
        include_once("Controller/ProductoController.php");
        $objectController=$get_controller."Controller";
        $controller=new $objectController();
        $controller->$get_view();

    }else {
        include_once("Controller/InicioController.php");
        $objectController="InicioController";
        $controller=new $objectController();
        $controller->inicio();
    }
    
    
break;

case "Venta":
    if($get_view=="InicioVenta"){
        include_once("Controller/VentaController.php");
        $objectController=$get_controller."Controller";
        $controller=new $objectController();
        $controller->$get_view();
    }elseif($get_view=="CrearVenta"){
        include_once("Controller/VentaController.php");
        $objectController=$get_controller."Controller";
        $controller=new $objectController();
        $controller->$get_view();
    }elseif($get_view=="VentaPorProducto"){
        include_once("Controller/VentaController.php");
        $objectController=$get_controller."Controller";
        $controller=new $objectController();
        $controller->$get_view();
    }else {
        include_once("Controller/InicioController.php");
        $objectController="InicioController";
        $controller=new $objectController();
        $controller->inicio();
    }
break;

default:
include_once("Controller/InicioController.php");
$objectController="InicioController";
$controller=new $objectController();
$controller->inicio();

}



?>