<div class="card text-center mt-5">
  <div class="card-header">
   
  </div>
  <div class="card-body m-3">
    <h5 class="card-title">Crear Venta</h5>

<form method="POST" action="#">
  <div class="form-group">
    <label for="nombre">ID del producto</label>
    <input type="number" class="form-control" id="idpro" name="idpro" aria-describedby="emailHelp">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Cantidad a vender</label>
    <input type="text" class="form-control" id="cantvender" name="cantvender">
  </div>

<input type="submit" value="Enviar Formulario" class="btn btn-primary">
</form>
</div>
  <div class="card-footer text-muted">
 
  </div>
</div>
