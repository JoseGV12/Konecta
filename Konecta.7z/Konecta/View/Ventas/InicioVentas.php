
<a href="?Controller=Venta&View=CrearVenta" class="btn btn-info mt-3"> Agregar Una Venta </a>

<div class="card text-center mt-5">
  <div class="card-header">
    Ventas
  </div>
  <div class="card-body">
    <h5 class="card-title">Ventas</h5>
    <table class="table">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">NOMBRE PRODUCTO</th>
      <th scope="col">STOCK</th>
      <th scope="col">CANTIDAD</th>
    </tr>
  </thead>
  <tbody>
      <?php foreach($ventas as $venta){ ?> 
    <tr>
      <th scope="row"><?php echo $venta['ID_VENTA'] ?></th>
      <td><?php echo $venta['NOMBRE_PRODUCTO'] ?></td>
      <td><?php echo $venta['STOCK'] ?></td>
      <td><?php echo $venta['CANTIDAD'] ?></td>
    </tr>
  <?php } ?>
  </tbody>
</table>
  </div>
  <div class="card-footer text-muted">
    2 days ago
  </div>
</div>



