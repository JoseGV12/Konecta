<?php 
$get_controller="Inicio";
$get_view="incio";

if(isset($_GET['Controller'])&&isset($_GET['View'])){
$get_controller=$_GET['Controller'];
$get_view=$_GET['View'];

}

include_once("View/template.php");

?>