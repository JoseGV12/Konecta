<?php
include_once("Model/ProductoModel.php");
class ProductoController{
    public function InicioProducto(){
        $productos=Producto::inicio();
        include_once("View/Productos/InicioProductos.php");
    }

    public function CrearProducto(){
        if(isset($_POST['nombre'])&&isset($_POST['referencia'])&&isset($_POST['precio'])&&isset($_POST['peso'])&&isset($_POST['categoria'])&&isset($_POST['stock'])){
            $nombre=$_POST['nombre'];
            $referencia=$_POST['referencia'];
            $precio=$_POST['precio'];
            $peso=$_POST['peso'];
            $categoria=$_POST['categoria'];
            $stock=$_POST['stock'];
            $pro=Producto::crear($nombre,$referencia,$precio,$peso,$categoria,$stock);
            $productos=Producto::inicio();
        header("Location:?Controller=Producto&View=InicioProducto");
        }
        include_once("View/Productos/CrearProductos.php");

    }

    public function EditarVistaProducto(){
        if(isset($_GET['ID'])){
         $id=$_GET['ID'];
         $producto=Producto::editar($id);

         include_once("View/Productos/EditarProducto.php");
        }
    }
    public function EditarInformacionProducto(){
        if(isset($_POST['id'])&&isset($_POST['nombre'])&&isset($_POST['referencia'])&&isset($_POST['precio'])&&isset($_POST['peso'])&&isset($_POST['categoria'])&&isset($_POST['stock'])){
           $id=$_POST['id'];
           $nombre=$_POST['nombre'];
           $referencia=$_POST['referencia'];
           $precio=$_POST['precio'];
           $peso=$_POST['peso'];
           $categoria=$_POST['categoria'];
           $stock=$_POST['stock'];
            Producto::guardar($id,$nombre,$referencia,$precio,$peso,$categoria,$stock);
            $productos=Producto::inicio();
            header("Location:?Controller=Producto&View=InicioProducto");
            }
        }
        public function ProductoMasStock(){
            $productos=Producto::ProductoMasStock();
            include_once("View/Productos/ProductoMasStock.php");
        }
        public function EliminarProducto(){
            if(isset($_GET['ID'])){
                $id=$_GET['ID'];
                Producto::eliminar($id);
                $productos=Producto::inicio();
                header("Location:?Controller=Producto&View=InicioProducto");
            }else {
                $productos=Producto::inicio();
                header("Location:?Controller=Producto&View=InicioProducto");
            }
        }
    }



?>