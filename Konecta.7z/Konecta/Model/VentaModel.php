<?php
include_once("Model/Conexion.php");
class Venta{
    public $ID;
    public $ID_PRODUCTO;
    public $CANTIDAD;

    public function __construct($ID,$ID_PRODUCTO,$CANTIDAD){
$this->ID=$ID;
$this->ID_PRODUCTO=$ID_PRODUCTO;
$this->CANTIDAD=$CANTIDAD;
}
public static function inicio(){
$con=DB::CrearInstancia();
$sql=$con->query("SELECT VENTAS.ID AS ID_VENTA,ID_PRODUCTO,CANTIDAD,NOMBRE_PRODUCTO,STOCK FROM VENTAS JOIN PRODUCTOS WHERE VENTAS.ID_PRODUCTO=PRODUCTOS.ID");
$ventas=$sql->fetchAll();

return $ventas;
}

public static function crear($ID_PRODUCTO,$CANTIDAD){
    $con=DB::CrearInstancia();
        $sql=$con->prepare("SELECT * FROM PRODUCTOS WHERE ID=?");
        $sql->execute(array($ID_PRODUCTO));
        $producto=$sql->fetch();
        if($producto != null){
            if($producto['STOCK'] >= intval($CANTIDAD)){
                $id_producto_a_modificar=$producto['ID'];
                $valor=intval($producto['STOCK'])-intval($CANTIDAD);
                $sql=$con->prepare("UPDATE PRODUCTOS SET STOCK=? WHERE ID=?");
                $sql->execute(array($valor,$id_producto_a_modificar));
                $sql2=$con->prepare("INSERT INTO VENTAS(ID_PRODUCTO,CANTIDAD) VALUES(?,?)");
                $sql2->execute(array($id_producto_a_modificar,$CANTIDAD));
                return 0;
              }else{
                   return 2;
              } 
        }else {
            return 1;
        }
    if(isset($producto)){
    
    }else {
       return "No existe";
    }
   
 }
public static function VentaPorProducto(){
    $con=DB::CrearInstancia();
    $sql=$con->query("SELECT VENTAS.ID AS ID_VENTA,PRODUCTOS.ID AS ID_PRODUCTO,ID_PRODUCTO,CANTIDAD,COUNT(NOMBRE_PRODUCTO) AS NUMERO_VENTAS,NOMBRE_PRODUCTO,STOCK FROM VENTAS JOIN PRODUCTOS WHERE VENTAS.ID_PRODUCTO=PRODUCTOS.ID GROUP BY NOMBRE_PRODUCTO DESC LIMIT 1");
    $ventas=$sql->fetchAll();
    return $ventas;

}

}

?>